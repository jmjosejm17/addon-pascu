#-*- coding: utf-8 -*-
'''
    Torrenter v2 plugin
    Copyright (C) 2015 srg70, RussakHH, DiMartino
    '''

import sys
import os
import imp
from ctypes import CDLL
import platform


def get_platform():

    ret = {
        "arch": sys.maxsize > 2 ** 32 and "x64" or "x86",
    }
    _platform = sys.platform
    if _platform == "linux3":
        ret["os"] = "android"
        if "arm" in os.uname()[4] or "aarch64" in os.uname()[4]:
            ret["arch"] = "arm"
    elif _platform == "linux2":
        ret["os"] = "linux"
        uname = os.uname()[4]
        if "arm" in uname:
            if "armv7" in uname:
                ret["arch"] = "armv7"
            elif "armv6" in uname:
                ret["arch"] = "armv6"
            else:
                ret["arch"] = "arm"
        elif "mips" in uname:
            if sys.maxunicode > 65536:
                ret["arch"] = 'mipsel_ucs4'
            else:
                ret["arch"] = 'mipsel_ucs2'
        elif "aarch64" in uname:
            if sys.maxunicode > 65536:
                ret["arch"] = 'aarch64_ucs4'
            else:
                ret["arch"] = 'aarch64_ucs2'

    elif _platform == "darwin":
       
        try:
            check_platform = platform.machine()
            ret["os"] = "darwin"
        except:
            ret["os"] = "ios"
            ret["arch"] = "arm"
    elif "win" in _platform:
         ret["os"] = "windows"

    ret = get_system(ret)
    return ret

def get_system(ret):
    ret["system"] = ''
   
    if ret["os"] == 'windows':
        ret["system"] = 'windows'
    elif ret["os"] == "linux" and ret["arch"] == "x64":
        ret["system"] = 'linux_x86_64'
    elif ret["os"] == "linux" and ret["arch"] == "x86":
        ret["system"] = 'linux_x86'
    elif ret["os"] == "linux" and "aarch64" in ret["arch"]:
        ret["system"] = 'linux_' + ret["arch"]
    elif ret["os"] == "linux" and ("arm" or "mips" in ret["arch"]):
        ret["system"] = 'linux_'+ret["arch"]
    elif ret["os"] == "android":
        if ret["arch"]=='arm':
            ret["system"] = 'android_armv7'
        else:
            ret["system"] = 'android_x86'
    elif ret["os"] == "darwin":
        ret["system"] = 'darwin'
    elif ret["os"] == "ios" and ret["arch"] == "arm":
        ret["system"] = 'ios_arm'
   
    return ret

def get_libtorrent():
    _platform = get_platform()['system']

    THIS_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__),"."))
    dest_path = os.path.join(THIS_PATH, _platform)
    sys.path.insert(0, dest_path)

    if _platform in ['android_armv7', 'android_x86']:
        dll_path=os.path.join(dest_path, 'liblibtorrent.so')
        liblibtorrent = CDLL(dll_path)

    path_list = [dest_path]
    fp, pathname, description = imp.find_module('libtorrent', path_list)
    try:
        libtorrent = imp.load_module('libtorrent', fp, pathname, description)
    finally:
        if fp: fp.close()

    return libtorrent
