# coding: utf-8
# Module: __init__
# Created on: 24.07.2015
# Author: Roman Miroshnychenko aka Roman V.M.
# E-mail: romanvm@yandex.ua
# Licence: GPL v.3: http://www.gnu.org/copyleft/gpl.html
"""
YATP torrent client modules
"""

